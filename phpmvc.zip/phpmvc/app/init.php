<?php

require_once 'core/App/init.php';
require_once 'core/Controller.php';