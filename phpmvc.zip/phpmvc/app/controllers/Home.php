<?php

class Home {
	public function index()
	{
		echo 'home/index';
	}
}