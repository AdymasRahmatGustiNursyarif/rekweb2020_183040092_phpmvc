<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Halaman <?= $data['judul']; ?></title>
</head>
<body>